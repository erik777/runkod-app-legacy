
document.querySelector('.content .message').innerHTML = 'It works!';
